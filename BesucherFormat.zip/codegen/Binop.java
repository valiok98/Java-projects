package codegen;

public enum Binop {
  Minus, Plus, MultiplicationOperator, DivisionOperator, Modulo
}
