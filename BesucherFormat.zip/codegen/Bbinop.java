package codegen;

public enum Bbinop {
  And, Or
}
