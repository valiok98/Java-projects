package codegen;

public class False extends Condition {

  @Override
  public void accept(Visitor visitor) {
    visitor.visit(this);
  }
  public String toString() {
	  return "false";
  }

}
